
# HEALPix in JavaScript

    var hp = new HEALPix();
    var ring = hp.nest2ring(16, 1130);
    var nest = hp.ring2nest(16, 1504);